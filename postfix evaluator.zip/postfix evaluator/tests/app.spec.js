describe('Testing Controller', function(){
	beforeEach(angular.mock.module('postfixApp'));

    var $controller, $scope, controller;;
	
    beforeEach(inject(function(_$controller_){
    $controller = _$controller_;
    }));
	 
	beforeEach(function() {
      $scope = {};
      controller = $controller('postfixCtrl', { $scope: $scope });
    });
	
	it('should return postfix evaluation 5 if the input expression is 2 3 +', function() {
      $scope.expression = '2 3 +';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(5);
    });
	it('should return postfix evaluation 11 if the input expression is 2 3 + 4 4 * -', function() {
      $scope.expression = '2 3 + 4 4 * -';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(11);
    });
	it('should return postfix evaluation 8 if the input expression is -5 6 +', function() {
      $scope.expression = '-5 6 +';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(1);
    });
	it('should return postfix evaluation 8 if the input expression is -5 -6 + 76 9 * /', function() {
      $scope.expression = '-5 -6 + 76 9 * /';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(-62.18181818181818);
    });
	it('should return postfix evaluation 12 if the input expression is a ', function() {
      $scope.expression = 'a ';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual("INVALID VALUE");
    });
	it('should return error message if the input expression is 5 / * -', function() {
      $scope.expression = '5 / * - *';
	  $scope.output = $scope.postfixEvaluator($scope.expression);
	  expect($scope.output).toEqual("INVALID VALUE");
    }); 
});