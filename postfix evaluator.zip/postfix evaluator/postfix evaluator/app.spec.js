describe('Testing Controller', function(){
	beforeEach(angular.mock.module('postfixApp'));

    var $controller, $scope, controller;;
	
    beforeEach(inject(function(_$controller_){
    $controller = _$controller_;
    }));
	 
	beforeEach(function() {
      $scope = {};
      controller = $controller('postfixCtrl', { $scope: $scope });
    });
	
	it('should return postfix evaluation 5 if the input expression is 2 3 +', function() {
      $scope.expression = '2 3 +';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(5);
    });
	it('should return postfix evaluation 8 if the input expression is 2 3 ^', function() {
      $scope.expression = '2 3 ^';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(8);
    });
	it('should return postfix evaluation 11 if the input expression is 2 3 + 4 4 * -', function() {
      $scope.expression = '2 3 + 4 4 * -';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(11);
    });
	it('should return postfix evaluation 1 if the input expression is 3 4 -', function() {
      $scope.expression = '3 4 -';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(1);
    });
	it('should return postfix evaluation 12 if the input expression is 3 4 *', function() {
      $scope.expression = '3 4 *';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(12);
    });
	it('should return error message if the input expression is 5 / * -', function() {
      $scope.expression = '5 / * - *';
	  $scope.output = $scope.postfixEvaluator($scope.expression);
	  expect($scope.output).toEqual("error");
    }); 
});