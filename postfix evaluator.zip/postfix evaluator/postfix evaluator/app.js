var app = angular.module('postfixApp', []);
app.controller('postfixCtrl', function($scope, $location) {
	$scope.result="";
    $scope.postfixEvaluator = function(postfix){
		
		//To check the functions are numeric.
		String.prototype.isNumber = function() {
			return !isNaN(parseFloat(this)) && isFinite(this); // returns true if numeric
		}
		
		var resultStack = [];
        expression = postfix.split(" "); //splitting string based on spaces between characters.
		//Check if character is operand or operator.
        for(var i = 0; i < expression.length; i++) {			
            if(expression[i].isNumber()) {             //operand
                resultStack.push(expression[i]);
            } else { 
				var a = resultStack.pop();
				var b = resultStack.pop();
				var operator = expression[i];
				switch(operator){
					case "+": 
						resultStack.push(parseInt(a) + parseInt(b));
						break;
					case "-":
						resultStack.push(parseInt(a) - parseInt(b));
						break;
					case "*":
						resultStack.push(parseInt(a) * parseInt(b));
						break;
					case "/":
						resultStack.push(parseInt(a) / parseInt(b));
						break;
					case "^":
						resultStack.push(Math.pow(parseInt(b), parseInt(a)));
						break;					
				}
            }
        }
		//Check stack has only one value at the end. 
        if(resultStack.length > 1 || resultStack.length <=0 || isNaN(resultStack[0])) {
            return "error";
        } else {
			var result = resultStack.pop();
             alert("The Result of Evaluation is: " + result); // Result
			 return result;
        }
    }
});



