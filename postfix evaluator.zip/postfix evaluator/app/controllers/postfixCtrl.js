
app.controller('postfixCtrl', ['$scope', 'evaluatorService', function($scope, evaluatorService) {
	$scope.postfixExp="";
	$scope.evaluate = function() {
		$scope.output = evaluatorService.postfixEvaluator($scope.postfixExp);
	}
    
}]);
